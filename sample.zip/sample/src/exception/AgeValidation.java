package exception;
import java.util.*;
public class AgeValidation
{
	public static void main(String[] args) {
		int age;
		System.out.println();
		
		
	}
}
		