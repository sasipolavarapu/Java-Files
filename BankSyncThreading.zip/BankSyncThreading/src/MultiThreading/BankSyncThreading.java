package MultiThreading;
class customer{
	int amount=0;
	int flag=0;
	public synchronized void withdrawl(int amount)
	{
		System.out.println(Thread.currentThread().getName()+" is going to withdrawl");
		if(flag==0)
		{
			try {
				System.out.println("wait..there is no balance in your account");
				wait();
			}catch(Exception e)
			{
				System.out.println("Insufficient amount");
			}
		}
		this.amount-=amount;
		System.out.println(" withdrawl amount is "+amount);
		
	}
	public synchronized void deposit(int amount)
	{
		System.out.println(Thread.currentThread().getName()+" is going to deposited");
		this.amount+=amount;
		System.out.println("After deposited the amount is "+amount);
		notifyAll();
		flag=1;
		
	}
}
	
public class BankSyncThreading {
		public static void main(String[] args)
		{
			customer c=new customer();
			Thread t1=new Thread()
					{
						public void run()
						{
							c.withdrawl(5000);
							System.out.println("after withdrawl amount is "+c.amount);
						}
					};
			Thread t2=new Thread()
					{
						public void run()
						{
							c.deposit(7000);
							
							System.out.println("the deposited amount is "+c.amount);
							c.deposit(2000);
							System.out.println("the total amount is "+c.amount);
							
						}
					};
			t1.setName("Sai");
			t2.setName("Ram");
			t1.start();
			t2.start();
		}
}
