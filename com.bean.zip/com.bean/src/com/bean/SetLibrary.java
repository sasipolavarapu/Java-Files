
	package com.bean;

	import java.util.Set;


	public class SetLibrary {
	 private int id;
	 private String name;
	 private Set<String> books;
	public SetLibrary(int id, String name, Set<String> books) {
		super();
		this.id = id;
		this.name = name;
		this.books = (Set<String>) books;
	}
	@Override
	public String toString() {
		return "Library [id=" + id + ", name=" + name + ", books=" + books + "]";
	}


	 
	}


