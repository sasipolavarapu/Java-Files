package collections;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TestSerializeLaptop {
static void serialize(Laptop l){

try{
FileOutputStream fos=new FileOutputStream("E:eg.txt");
ObjectOutputStream os=new ObjectOutputStream(fos);
os.writeObject(l);
os.close();
}
catch(IOException e){
e.printStackTrace();

}



}

public static void main(String[] args) throws IOException {
Laptop l=new Laptop("HP",1,32);
serialize(l);
System.out.println("Object serialized");

}
}
