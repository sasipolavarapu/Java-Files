package collections;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class TextFileReading {

	public static void main(String[] args) throws IOException{
	try {
		FileInputStream inputStream = new FileInputStream("E:eg.txt");
		InputStreamReader reader = new InputStreamReader(inputStream, "UTF-8");
		
		
		
		int ch;
		while((ch = reader.read())!= -1) {
			System.out.print((char) ch);
			
		}
		reader.close();
		
	}catch (IOException e) {
		e.printStackTrace();
	}
	
	}	
}
