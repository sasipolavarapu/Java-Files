package collections;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileWriter;

public class buffw {
	public static void main(String[] args) throws IOException
	{
	
		
		
		try
		{
			FileWriter f=new FileWriter("E:eg.txt",true);
			BufferedWriter buff=new BufferedWriter(f);
			buff.write("Sasi");
			buff.newLine();
			buff.write("Polavarapu");
			buff.close();
		
		}  catch (FileNotFoundException e) {
			e.printStackTrace();
			
		}
	}
}
