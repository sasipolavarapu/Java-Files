package collections;



import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

public class serialization {
static final String filepath="user.ser";
static void seralize(user user)
{
try
{
FileOutputStream fos=new FileOutputStream(filepath);
ObjectOutputStream outputStream=new ObjectOutputStream(fos);
outputStream.writeObject(user);
outputStream.close();
}catch(IOException e)
{
System.err.println(e);
}
}
static user deserialize()
{
user saveduser=null;
try
{
FileInputStream fis=new FileInputStream(filepath);
ObjectInputStream inputstream=new ObjectInputStream(fis);
saveduser=(user) inputstream.readObject();
inputstream.close();
}catch(IOException |ClassNotFoundException ex)
{
System.err.println(ex);
}
return saveduser;

}
public static void main(String args[])
{
String username="codejava";
String mail="info@code.java";
String password="1234";
Date birthday=new Date();
int age=20;
user newuser=new user(username,mail,password,birthday,age);
seralize(newuser);
user saveuser=deserialize();
if(saveuser!=null)
{
saveuser.printInfo();
}

}
}