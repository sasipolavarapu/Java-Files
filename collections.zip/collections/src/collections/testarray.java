package collections;
import java.util.ArrayList;
public class testarray {
	public static void main(String[] args) {
		ArrayList li=new ArrayList();
		
		li.add(10);
		li.add("Rahul");
		li.add(12.4);
		li.add(null);
		
		System.out.println(li);
		
		
		ArrayList l1=new ArrayList();
		l1.add("meena");
		l1.add(14);
		l1.add("Rahul");
		l1.add(null);
		li.addAll(l1);
		System.out.println(li);
		
		/*l1.remove(3);*/
		l1.add(1,13);
		System.out.println(l1);
	}
}
