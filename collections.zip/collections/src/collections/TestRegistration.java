package collections;
import java.util.Scanner;
public class TestRegistration {
public static void main(String[] args)
{
	String name, mobileno, mailid;
	String totprice;
	System.out.println("Enter the registration1 details");
	Scanner s= new Scanner(System.in);
	
	name=s.nextLine();
	mobileno=s.nextLine();
	mailid=s.nextLine();
	totprice=s.nextLine();
	
	
	System.out.println("Enter the registration2 details");
	Scanner s1= new Scanner(System.in);
	
	name=s.nextLine();
	mobileno=s.nextLine();
	mailid=s.nextLine();
	totprice=s.nextLine();
	if(s.equals(s1))
	{
		System.out.println("The objects are same");
	}
		else{
			System.out.println("The objects are not same");
	}
	}
}

