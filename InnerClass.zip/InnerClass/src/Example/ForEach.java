package Example;





public class ForEach {
	public static void main(String args[]) {
		
		for(Directions d:Directions.values()){
			System.out.println("values:" +d);
		}
	}
}
