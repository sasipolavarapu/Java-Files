package Outer1;
	
	class Age
	{
		int x=21;
		public void getAge() {}
			
		}
	
class AnonymousDemo
{
	public static void main(String[] args) {
		Age oj1= new Age() {
			public void getAge() {
				System.out.print("Age is " +x);
			}
		};
		
		oj1.getAge();
	}
}
