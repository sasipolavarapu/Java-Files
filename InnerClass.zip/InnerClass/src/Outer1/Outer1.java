package Outer1;

public class Outer1 {
static int x=100;

 static class Inner{
	int y=200;
	public void show() {
		System.out.println(x+" "+y);
	    }
	}
	
	


public static void main(String[] args){
	Outer1.Inner Obj=new Outer1.Inner();
	Obj.show();
} 
}
