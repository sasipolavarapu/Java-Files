package Outer1;

public class Outer {

}
