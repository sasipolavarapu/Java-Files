package com.setter;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSetter {

	public static void main(String[] args){
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("applicationCustomer.xml");
		
		
		Customer obj=(Customer)context.getBean("cust2");
		System.out.println(obj);
		
		
		
		
		
	}
	
}
