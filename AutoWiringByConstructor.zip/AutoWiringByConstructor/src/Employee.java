public class Employee
{
private Address addr;//type of variable

public Employee(){}

public Employee(Address addr)
{
this.addr = addr;
}

public Address getAddr()
{
return addr;
}
public void setAddr(Address addr)
{
this.addr = addr;
}

@Override
public String toString()
{
return "Employee [addr=" + addr + "]";
}

}