public class Address {
private int addId;
private String loc;

public String getLoc() {
return loc;
}

public void setLoc(String loc) {
this.loc = loc;
}

public int getAddId() {
return addId;
}

public void setAddId(int addId) {
this.addId = addId;
}

@Override
public String toString() {
return "Address [addId=" + addId + ", loc=" + loc + "]";
}

}
