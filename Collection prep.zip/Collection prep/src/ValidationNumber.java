import java.util.*;

public class ValidationNumber {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	String n= sc.nextLine();
	if(n.matches("[0-9]{3}[-]{1}[0-9]{3}[-]{1}[0-9]{4}")) {
		System.out.println("The number you entered is valid");
	}
	else{
		System.out.println("The number you entered is not the valid number");
	}
	
}
}
