import java.util.Scanner;

public class ReverseNumber {
	public static void main(String[] args)
	{
		int digit,r = 0;
		System.out.println("Enter the number");
		Scanner sc= new Scanner(System.in);
		int num=sc.nextInt();
		
		while(num!=0)
		{
			digit=num%10;
			r=r*10+digit;
			num=num/10;
		}
		System.out.println("the reverse number is"+r);
		
	}
}
