import java.util.*;
import java.io.*;

public class arraytocollections {
	public static void main(String args[]) throws IOException{
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the value of colors to be printed");
	int n=Integer.parseInt(br.readLine());
	String[] name=new String[n];
	
	for(int i=0;i<n;i++)
	{
		name[i]=br.readLine();
	}
	
	List<String> list= Arrays.asList(name);
	System.out.println();
	
	for(String li:list) {
		String str=li;
		System.out.println(str + " ");
	}
		
	
	}
}