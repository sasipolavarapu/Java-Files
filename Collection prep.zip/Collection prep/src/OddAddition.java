import java.io.IOException;
import java.util.*;
public class OddAddition {
@SuppressWarnings("resource")
public static void main(String[] args) throws IOException
{
	int digit,rem,odd=0;
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the value");
	int n=sc.nextInt();
	while(n!=0)
	{
		digit=n%10;
		
		rem=n%2;
		if(rem!=0){
		odd=odd+digit;
		}
		
	}
	n=n/10;
	
		if(odd%2==0)
		{
			System.out.println("The number is even");
		}
		else{
				System.out.println("The number is odd");
			}
		return;
	}

}

